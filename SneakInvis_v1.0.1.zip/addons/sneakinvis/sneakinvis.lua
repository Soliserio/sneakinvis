_addon.name = 'SneakInvis'
_addon.author = 'Soliserio'
_addon.version = '1.0.1'
_addon.commands = {'sneakinvis'}
local res = require('resources')
local clock = require('socket').gettime
local INV, CASE = 0, 7
local defs = {
    {buff=71, spell=137, item=4165, name='Sneak', item_name='Silent Oil'},
    {buff=69, spell=136, item=4164, name='Invisible', item_name='Prism Powder'},
}
local run, next_tick = nil, 0
local function say(s) windower.add_to_chat(207, '[SneakInvis] '..s) end
local function has(p,id)
    for _,v in pairs(p.buffs or {}) do if v==id then return true end end
    return false
end
local function count(bag,id)
    local n=0
    for _,v in pairs(windower.ffxi.get_items(bag) or {}) do
        if type(v)=='table' and v.id==id then n=n+(v.count or 0) end
    end
    return n
end
local function slot(bag,id)
    for k,v in pairs(windower.ffxi.get_items(bag) or {}) do
        if type(k)=='number' and type(v)=='table' and v.id==id and (v.count or 0)>0 then return k end
    end
end
local function can_spell(p,d)
    local s=res.spells[d.spell]
    local learned=windower.ffxi.get_spells() or {}
    local levels=s.levels or {}
    local permitted=(levels[p.main_job_id] and p.main_job_level>=levels[p.main_job_id])
        or (levels[p.sub_job_id] and p.sub_job_level>=levels[p.sub_job_id])
    local recasts=windower.ffxi.get_spell_recasts() or {}
    return learned[d.spell] and permitted and not has(p,6) and not has(p,29)
        and (p.vitals.mp or 0)>=s.mp_cost and recasts[s.recast_id]==0
end
local function can_jig(p)
    local known=false
    for _,v in pairs((windower.ffxi.get_abilities() or {}).job_abilities or {}) do
        if v==196 then known=true end
    end
    return known and (windower.ffxi.get_ability_recasts() or {})[218]==0 and not has(p,16)
end
local function wait_for(kind,d,seconds)
    run.phase=kind;run.d=d;run.deadline=clock()+seconds
end
local function cleanup(reason)
    run.reason=reason;run.phase='cleanup';run.deadline=clock()+12
end
local function finish()
    local p=windower.ffxi.get_player()
    if p and has(p,71) and has(p,69) then say('Confirmed: Sneak and Invisible active.')
    else
        local missing={}
        for _,d in ipairs(defs) do if not p or not has(p,d.buff) then missing[#missing+1]=d.name end end
        say('Incomplete: '..table.concat(missing,', ')..'. '..(run.reason or 'Check supplies, recasts, and action restrictions.'))
    end
    run=nil
end
local function tick()
    if not run then return end
    local now=clock()
    local info=windower.ffxi.get_info()
    local p=windower.ffxi.get_player()
    if not info or not info.logged_in or not p then run=nil;return end
    if run.phase~='cleanup' and (p.vitals.hp==0 or p.status==2 or p.status==3) then cleanup('Character is unable to act.') end
    if run.phase=='cleanup' then
        local pending=false
        for id,b in pairs(run.borrowed) do
            local excess=math.max(0,count(INV,id)-b.baseline)
            if excess>0 then
                pending=true
                local s=slot(INV,id)
                if not b.return_sent and s then
                    local bag=windower.ffxi.get_bag_info(CASE)
                    if bag and bag.enabled then
                        windower.ffxi.put_item(CASE,s,math.min(excess,1))
                        b.return_sent=true
                    end
                end
            elseif b.return_sent and count(CASE,id)<b.case_before then
                pending=true
            elseif not b.received and count(CASE,id)<b.case_before then
                pending=true -- Wait for an in-flight withdrawal, never assume it vanished.
            end
        end
        if not pending then finish()
        elseif now>=run.deadline then
            say('Unused borrowed supplies could not be confirmed back in Mog Case. Check Inventory and Case.')
            finish()
        end
        return
    end
    if now-run.started>120 then cleanup('Timed out; stand still and retry.');return end
    if run.phase=='spell' or run.phase=='jig' or run.phase=='item' then
        local succeeded=run.phase=='jig' and has(p,71) and has(p,69) or run.phase~='jig' and has(p,run.d.buff)
        -- Do not issue another action while the preceding action is resolving.
        if now<run.not_before then return end
        if succeeded or now>=run.deadline then
            if not succeeded then say('No buff confirmation from '..run.phase..'; trying the next available option.') end
            run.phase='ready';run.not_before=now+1
        end
        return
    end
    if run.phase=='cancel_sneak' then
        if not has(p,71) then
            if can_jig(p) then
                windower.send_command('input /ja "Spectral Jig" <me>')
                wait_for('jig',defs[1],8);run.not_before=now+2
            else run.phase='ready' end
        elseif now>=run.deadline then run.phase='ready' end
        return
    end
    if run.phase=='withdraw' then
        local b=run.borrowed[run.d.item]
        if count(INV,run.d.item)>b.baseline and count(CASE,run.d.item)<b.case_before then
            b.received=true;run.phase='ready';run.not_before=now+1
        elseif now>=run.deadline then cleanup('Mog Case transfer was not confirmed.') end
        return
    end
    if now<(run.not_before or 0) then return end
    if has(p,71) and has(p,69) then cleanup();return end
    -- Wait for standing still; do not alter follow, Trust, or HealBot settings.
    local mob=windower.ffxi.get_mob_by_target('me')
    if not mob then return end
    if run.x~=mob.x or run.y~=mob.y then
        run.x,run.y=mob.x,mob.y;run.stationary=now;return
    end
    if now-(run.stationary or now)<1 then return end
    if p.status~=0 then return end
    local d=not has(p,71) and defs[1] or defs[2]
    if not run.tried['spell'..d.buff] and can_spell(p,d) then
        run.tried['spell'..d.buff]=true
        say('Using '..d.name..' spell.')
        windower.send_command('input /ma "'..d.name..'" <me>')
        wait_for('spell',d,12);run.not_before=now+4;return
    end
    if not run.tried.jig and can_jig(p) then
        run.tried.jig=true
        if has(p,71) then
            say('Replacing existing Sneak so Spectral Jig can apply both buffs.')
            windower.ffxi.cancel_buff(71)
            wait_for('cancel_sneak',d,5)
        else
            say('Using Spectral Jig.')
            windower.send_command('input /ja "Spectral Jig" <me>')
            wait_for('jig',d,8);run.not_before=now+2
        end
        return
    end
    if run.tried['item'..d.buff] then cleanup('No successful remaining method for '..d.name..'.');return end
    if count(INV,d.item)==0 then
        local b=windower.ffxi.get_bag_info(CASE)
        local inventory=windower.ffxi.get_bag_info(INV)
        local s=slot(CASE,d.item)
        if not b or not b.enabled or not s then cleanup(d.item_name..' unavailable in Inventory or Mog Case.');return end
        if not inventory or inventory.count>=inventory.max then cleanup('Inventory is full; free one slot.');return end
        if run.borrowed[d.item] then cleanup('Borrowed item was not available for use.');return end
        run.borrowed[d.item]={baseline=count(INV,d.item),case_before=count(CASE,d.item)}
        say('Retrieving one '..d.item_name..' from Mog Case.')
        windower.ffxi.get_item(CASE,s,1)
        wait_for('withdraw',d,12);return
    end
    run.tried['item'..d.buff]=true
    say('Using '..d.item_name..'.')
    windower.send_command('input /item "'..d.item_name..'" <me>')
    wait_for('item',d,10);run.not_before=now+3
end
windower.register_event('prerender',function()
    if clock()<next_tick then return end
    next_tick=clock()+0.25
    tick()
end)
windower.register_event('addon command',function(command)
    command=(command or 'start'):lower()
    if command=='status' then say(run and ('Active: '..run.phase) or 'Idle.');return end
    if command=='stop' then if run then cleanup('Stopped by user.') end;return end
    if command~='start' then say('Commands: start, stop, status.');return end
    if run then say('Already running; duplicate request ignored.');return end
    local p=windower.ffxi.get_player()
    if not p or not windower.ffxi.get_info().logged_in then say('Not logged in.');return end
    if p.status~=0 or p.vitals.hp==0 then say('Disengage and stand still before starting.');return end
    run={phase='ready',started=clock(),tried={},borrowed={}}
    say('Checking spells, then Spectral Jig, then consumables. Stand still.')
end)
windower.register_event('zone change','logout','unload',function()
    if run and next(run.borrowed) then say('Stopped during travel/unload; check Inventory for borrowed supplies.') end
    run=nil
end)
